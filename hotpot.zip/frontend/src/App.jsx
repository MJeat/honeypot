import React from "react";
import Login from "./pages/Login";

export default function App() {
  return <Login />;
}
